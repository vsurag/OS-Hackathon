import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [requests, setRequests] = useState("98,183,37,122,14,124,65,67");
  const [head, setHead] = useState(53);
  const [diskSize, setDiskSize] = useState(200);
  const [algorithm, setAlgorithm] = useState("C-SCAN");
  const [result, setResult] = useState(null);

  const runAlgorithm = async () => {
    const requestArray = requests.split(',').map(Number);
    const res = await axios.post('http://localhost:3001/schedule', {
      requests: requestArray,
      head: Number(head),
      diskSize: Number(diskSize),
      algorithm
    });
    setResult(res.data);
  };

  return (
    <div className="container">
      <h2>Disk Scheduling Algorithm Simulator</h2>

      <div className="form-group">
        <label>Select Algorithm</label>
        <select value={algorithm} onChange={(e) => setAlgorithm(e.target.value)}>
          <option value="FCFS">FCFS</option>
          <option value="SSTF">SSTF</option>
          <option value="SCAN">SCAN</option>
          <option value="LOOK">LOOK</option>
          <option value="C-SCAN">C-SCAN</option>
          <option value="C-LOOK">C-LOOK</option>
        </select>
      </div>

      <div className="form-group">
        <label>Disk Requests</label>
        <input
          value={requests}
          onChange={(e) => setRequests(e.target.value)}
          type="text"
        />
      </div>

      <div className="form-group">
        <label>Head Pointer Position</label>
        <input
          type="number"
          value={head}
          onChange={(e) => setHead(e.target.value)}
        />
      </div>

      <div className="form-group">
        <label>Disk Size</label>
        <input
          type="number"
          value={diskSize}
          onChange={(e) => setDiskSize(e.target.value)}
        />
      </div>

      <button onClick={runAlgorithm}>Run {algorithm}</button>

      {result && (
        <div className="result">
          <h3>Seek Sequence:</h3>
          <p>{result.seekSequence.join(" → ")}</p>
          <h4>Total Seek Count: {result.seekCount}</h4>
        </div>
      )}
    </div>
  );
}

export default App;
