// schedulers.js

function runFCFS(requests, head) {
    let seekCount = 0;
    let seekSequence = [];
  
    for (let req of requests) {
      seekSequence.push(req);
      seekCount += Math.abs(head - req);
      head = req;
    }
  
    return { seekCount, seekSequence };
  }
  
  function runSSTF(requests, head) {
    let seekCount = 0;
    let seekSequence = [];
    let remaining = [...requests];
  
    while (remaining.length > 0) {
      let closest = remaining.reduce((a, b) =>
        Math.abs(head - a) < Math.abs(head - b) ? a : b
      );
      seekCount += Math.abs(head - closest);
      seekSequence.push(closest);
      head = closest;
      remaining.splice(remaining.indexOf(closest), 1);
    }
  
    return { seekCount, seekSequence };
  }
  
  function runSCAN(requests, head, diskSize) {
    let seekCount = 0;
    let seekSequence = [];
    let left = requests.filter(r => r < head).sort((a, b) => b - a);
    let right = requests.filter(r => r >= head).sort((a, b) => a - b);
  
    for (let r of right) {
      seekCount += Math.abs(head - r);
      seekSequence.push(r);
      head = r;
    }
  
    if (left.length > 0) {
      seekCount += Math.abs(head - (diskSize - 1));
      head = diskSize - 1;
    }
  
    for (let r of left) {
      seekCount += Math.abs(head - r);
      seekSequence.push(r);
      head = r;
    }
  
    return { seekCount, seekSequence };
  }
  
  function runLOOK(requests, head) {
    let seekCount = 0;
    let seekSequence = [];
    let left = requests.filter(r => r < head).sort((a, b) => b - a);
    let right = requests.filter(r => r >= head).sort((a, b) => a - b);
  
    for (let r of right) {
      seekCount += Math.abs(head - r);
      seekSequence.push(r);
      head = r;
    }
  
    for (let r of left) {
      seekCount += Math.abs(head - r);
      seekSequence.push(r);
      head = r;
    }
  
    return { seekCount, seekSequence };
  }
  
  function runCLOOK(requests, head) {
    let seekCount = 0;
    let seekSequence = [];
    let left = requests.filter(r => r < head).sort((a, b) => a - b);
    let right = requests.filter(r => r >= head).sort((a, b) => a - b);
  
    for (let r of right) {
      seekCount += Math.abs(head - r);
      seekSequence.push(r);
      head = r;
    }
  
    if (left.length > 0) {
      seekCount += Math.abs(head - left[0]);
      head = left[0];
    }
  
    for (let r of left) {
      seekCount += Math.abs(head - r);
      seekSequence.push(r);
      head = r;
    }
  
    return { seekCount, seekSequence };
  }
  
  function runCSCAN(requests, head, diskSize) {
    let seekSequence = [];
    let seekCount = 0;
    let left = [], right = [];
  
    requests.forEach(req => {
      if (req < head) left.push(req);
      else right.push(req);
    });
  
    left.sort((a, b) => a - b);
    right.sort((a, b) => a - b);
  
    for (let r of right) {
      seekSequence.push(r);
      seekCount += Math.abs(head - r);
      head = r;
    }
  
    if (right.length > 0) {
      seekCount += (diskSize - head - 1); // move to end
      seekCount += (diskSize - 1);        // jump to start
      head = 0;
    }
  
    for (let r of left) {
      seekSequence.push(r);
      seekCount += Math.abs(head - r);
      head = r;
    }
  
    return { seekCount, seekSequence };
  }
  
  module.exports = {
    runFCFS,
    runSSTF,
    runSCAN,
    runLOOK,
    runCLOOK,
    runCSCAN
  };
  