const express = require("express");
const cors = require("cors");
const {
  runFCFS,
  runSSTF,
  runSCAN,
  runLOOK,
  runCLOOK,
  runCSCAN
} = require("./schedulers");

const app = express();
app.use(cors());
app.use(express.json());

app.post("/schedule", (req, res) => {
  const { requests, head, diskSize, algorithm } = req.body;

  let result;
  switch (algorithm) {
    case "FCFS":
      result = runFCFS(requests, head);
      break;
    case "SSTF":
      result = runSSTF(requests, head);
      break;
    case "SCAN":
      result = runSCAN(requests, head, diskSize);
      break;
    case "LOOK":
      result = runLOOK(requests, head);
      break;
    case "C-LOOK":
      result = runCLOOK(requests, head);
      break;
    case "C-SCAN":
    default:
      result = runCSCAN(requests, head, diskSize);
      break;
  }

  res.json(result);
});

app.listen(3001, () => console.log("Backend running on port 3001"));
